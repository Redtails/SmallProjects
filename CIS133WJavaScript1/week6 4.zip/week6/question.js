console.log("PCC Housing Insecurity Survey Questions");

function createSurveyQuestions() {
  var q1 = new MultipleChoiceQuestionOther(
    "Demographic",
    'What is your status at PCC',
      [ "Full time student",
      "Part time student",
      "GED student",
      "High School dual enrollment",
      "Work Study",
      "Full time Faculty",
      "Part time Faculty",
      "Management",
      ]
    ); 
  var q2 = new MultipleSelectQuestion(
    "Sources of Income",
    "Please select all sources of income that apply",
  [ "Employment",
    "Parents/Guardians",
    "School Loans",
    "Alimony",
    "Scholarships/grants",
    "Disability",
    "Veterans benefits",
  ]
  );
  var q3 = new ShortAnswerQuestion( 
   "Age",
   "What's your Age",
   );

  var q4 = new ShortAnswerQuestion(
    "Zip Code",
    "Whats your Zip Code",
  );
  var q5 = new MultipleChoiceQuestion(
    "Income",
    "What is your yearly income",
    [
      "Under 10,000",
      "15,000 - 19,999",
      "20,000 - 24,999",
      "30,000 - 39,999",
      "40,000 - 59,999",
      "60,000 and above",
    ]
  );
  
  var allQuestions = [q1,q2,q3,q4,q5];
  for (var counter = 0; counter < allQuestions.length; counter++) {
    allQuestions[counter].number = counter + 1;
  }
  var s1 = new QuestionSection("Housing", [q1, q2]);
  var s2 = new QuestionSection("Demographics",[q3 ,q4 ,q5]);

  var allSections = [s1,s2];

  for(var counter = 0; counter < allSections.length; counter++){ 
    allSections[counter].number = counter + 1;
  }
  return new Survey("PCC Housing Insecurity Survey", [s1,s2]);
  }
  
function submit(){
  console.log("Answer submitted.")
}
window.addEventListener("load", function() {
  var Survey = createSurveyQuestions();
  this.document.getElementById("survey").innerHTML = Survey.toHTML();
  this.document.getElementById("submit").addEventListener("click", submit);
})